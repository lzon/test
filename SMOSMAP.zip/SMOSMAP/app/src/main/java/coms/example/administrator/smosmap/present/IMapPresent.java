package coms.example.administrator.smosmap.present;

import android.content.Context;

public interface IMapPresent {
    void bind(Context context);
}
