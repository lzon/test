package coms.example.administrator.smosmap.mode;

import java.security.Key;
import java.util.List;

public class AKeyTemplate {
    private List<KeyValue> list;

    public List<KeyValue> getList() {
        return list;
    }

    public void setList(List<KeyValue> list) {
        this.list = list;
    }
}
