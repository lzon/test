package coms.example.administrator.smosmap;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.JsonWriter;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import coms.example.administrator.smosmap.mode.AKeyTemplate;
import coms.example.administrator.smosmap.mode.KeyValue;
import coms.example.administrator.smosmap.mode.MapJianWei;
import coms.example.administrator.smosmap.mode.Postion;
import coms.example.administrator.smosmap.mode.RelateProp;
import coms.example.administrator.smosmap.present.MapPresentImp;
import coms.example.administrator.smosmap.view.IMapView;

public class MainActivity extends AppCompatActivity implements IMapView, View.OnClickListener, View.OnLongClickListener, View.OnTouchListener {
    private static final String DEBUG_TAG = "UUIUI____";
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            "android.permission.READ_EXTfERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE"};
    String str;
    private MapPresentImp mapPresent;

    private Handler handler = new Handler();
    private int statusBarHeight;
    private int rW = 102;
    private int rH = 102;
    private AKeyTemplate keyTemplate;

    @Override
    public boolean onKeyLongPress(int keyCode, KeyEvent event) {
        return super.onKeyLongPress(keyCode, event);
    }

    private List<FrameLayout> listF;
    private List<Button> listFa;
    RelativeLayout relativeLayoutMain;
    private View view;
    //------------------1
    private Button buttonChangGuiLB;
    private Button buttonChangGuiLT;
    private Button buttonChangGuiLS;
    private Button buttonChangGuiRB;
    private Button buttonChangGuiRT;
    private Button buttonChangGuiRS;
    //------------------2
    private Button buttonChangGuiZUO;
    private Button buttonChangGuiYOU;
    private Button buttonChangGuiSHANG;
    private Button buttonChangGuiXIA;
    private Button buttonChangGuiBK;
    //------------------3
    private Button buttonChangGuiM1;
    private Button buttonChangGuiM2;
    private Button buttonChangGuiM3;
    private Button buttonChangGuiM4;
    //------------------4
    private Button buttonChangGuiA;
    private Button buttonChangGuiB;
    private Button buttonChangGuiX;
    private Button buttonChangGuiY;
    private Button buttonChangGuiL;
    private Button buttonChangGuiR;

    /*zuhe*/
    //------------------1
    private Button buttonZuHeLB_A;
    private Button buttonZuHeLB_B;
    private Button buttonZuHeLT_A;
    private Button buttonZuHeLT_B;
    private Button buttonZuHeRB_A;
    private Button buttonZuHeRB_B;
    //------------------2
    private Button buttonZuHeLB_X;
    private Button buttonZuHeLB_Y;
    private Button buttonZuHeLT_X;
    private Button buttonZuHeLT_Y;
    private Button buttonZuHeRB_X;
    private Button buttonZuHeRB_Y;
    //------------------3
    private Button buttonZuHeM1_A;
    private Button buttonZuHeM1_B;
    private Button buttonZuHeM2_A;
    private Button buttonZuHeM2_B;
    private Button buttonZuHeRT_A;
    private Button buttonZuHeRT_B;
    //------------------4
    private Button buttonZuHeM1_X;
    private Button buttonZuHeM1_Y;
    private Button buttonZuHeM2_X;
    private Button buttonZuHeM2_Y;
    private Button buttonZuHeRT_X;
    private Button buttonZuHeRT_Y;
    //------------------5
    private Button buttonZuHeM3_A;
    private Button buttonZuHeM3_B;
    private Button buttonZuHeM4_A;
    private Button buttonZuHeM4_B;
    //------------------6
    private Button buttonZuHeM3_X;
    private Button buttonZuHeM3_Y;
    private Button buttonZuHeM4_X;
    private Button buttonZuHeM4_Y;
    //layout
    private ScrollView scrollViewChangGui;
    private ScrollView scrollViewZuhe;
    private boolean isUp = true;
    private FrameLayout floatButton;
    private boolean scrollEnable;
    private OrientationEventListener mOrientationListener;
    private float downX;
    private float downY;
    private MapJianWei mapJianWei;
    private List<KeyValue> listKeyValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mapPresent = MapPresentImp.getInstance();
        mapPresent.bind(this);
        mapJianWei = new MapJianWei();
        keyTemplate = new AKeyTemplate();
        mapJianWei.setCompositeMode("1");
        mapJianWei.setDescription("xx");
        mapJianWei.setTemplateName("0");
        mapJianWei.setFooViewAlpha("alpha");
        listKeyValue = new ArrayList<>();
        scrollViewChangGui = findViewById(R.id.scroll_changguicontent);
        scrollViewZuhe = findViewById(R.id.scroll_zuhecontent);
        init();
        getPpi();


        mOrientationListener = new OrientationEventListener(this,
                SensorManager.SENSOR_DELAY_NORMAL) {
            @Override
            public void onOrientationChanged(int orientation) {
                Log.v(DEBUG_TAG, "Orientation changed to " + orientation);
            }
        };

        if (mOrientationListener.canDetectOrientation()) {
            Log.v(DEBUG_TAG, "Can detect orientation");
            mOrientationListener.enable();
        } else {
            Log.v(DEBUG_TAG, "Cannot detect orientation");
            mOrientationListener.disable();
        }

        scrollViewChangGui.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        System.out.println("事件：scrollViewChangGui MotionEvent。ACTION_DOWN");
                        downX = event.getX();
                        downY = event.getY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        float x = event.getRawX();
                        float y = event.getRawY();

                        final float xDistance = event.getX() - downX;
                        final float yDistance = event.getY() - downY;
                        System.out.println("事件：scrollViewChangGui MotionEvent。ACTION_MOVE::" + x + ",,,," + y);
                        if (isUp) {
                            if (xDistance != 0 && yDistance != 0) {
                                if (listFa.size() > 0) {
                                    int l = (int) (listFa.get(listFa.size() - 1).getLeft() + xDistance);
                                    int r = (int) (listFa.get(listFa.size() - 1).getRight() + xDistance);
                                    int t = (int) (listFa.get(listFa.size() - 1).getTop() + yDistance);
                                    int b = (int) (listFa.get(listFa.size() - 1).getBottom() + yDistance);
                                } else {
                                    break;
                                }
                                //v.layout(l, t, r, b);
                                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(rW, rH);
                                layoutParams.leftMargin = (int) (x - 50 / 2 - 30);
                                layoutParams.topMargin = (int) (y - 50 * 2 - 10);
                                listFa.get(listFa.size() - 1).setLayoutParams(layoutParams);
                            }
                            //setMove((int) (x - 50 / 2-30), (int) (y - 50*2-10));
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        isUp = false;
                        scrollEnable = false;
                        //Toast.makeText(MainActivity.this, "x值:" + event.getX() + "  y值:" + event.getY(), Toast.LENGTH_SHORT).show();
                        break;
                }
                return scrollEnable;
            }
        });
        scrollViewZuhe.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
//                onTouchEvent(event);
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        break;
                    case MotionEvent.ACTION_MOVE:
                        float x = event.getRawX();
                        float y = event.getRawY();
                        break;
                    case MotionEvent.ACTION_UP:
                        isUp = false;
                        scrollEnable = false;
                        break;
                }
                return scrollEnable;
            }
        });


    }


    private void getPpi() {
        DisplayMetrics metric = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metric);
        int width = metric.widthPixels;  // 屏幕宽度（像素）
        int height = metric.heightPixels;  // 屏幕高度（像素）
        int midu = metric.densityDpi;
        float bizhi = metric.density;
        Log.e("like", "输出：" + "height = " + height + "width=" + width + "dpi=" + midu + "bizhi=" + bizhi);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // 在这里添加屏幕切换后的操作
        System.out.println("newConfig. = " + newConfig.orientation);
        if (mBluetoothGatt != null && isServiceConnected) {
            BluetoothGattService gattService = mBluetoothGatt.getService(UUID_SERVICE);
            BluetoothGattCharacteristic characteristic = gattService.getCharacteristic(UUID_WRITE);
            DisplayMetrics metrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(metrics);
            int width = metrics.widthPixels;
            int hight = metrics.widthPixels;

            byte[] rAndO = new byte[19];
            rAndO[0] = 0x10;
            //分辨率，⻓长度的数据
            rAndO[1] = intToByte4(width)[0];
            rAndO[2] = intToByte4(width)[1];
            rAndO[3] = intToByte4(hight)[0];
            rAndO[4] = intToByte4(hight)[1];
            // 0： 表示屏幕没有旋转
            // 1： 表示屏幕有旋转
            if (newConfig.orientation == 1) { //竖屏
                rAndO[5] = 1;
            }
            if (newConfig.orientation == 2) { //
                rAndO[5] = 0;
            }
            characteristic.setValue(rAndO);
            characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            mBluetoothGatt.writeCharacteristic(characteristic);
        }
    }



    private Button floatButtona;

    private FrameLayout initFloatButton(Drawable resource, View v) {
        floatButtona = new Button(MainActivity.this);
        floatButtona.setBackground(v.getBackground());
        floatButtona.setTag(v.getTag());
        RelativeLayout.LayoutParams relativeLayoutnew = new RelativeLayout.LayoutParams(rW, rH);
        int[] location = new int[2];
        v.getLocationInWindow(location);
        if (floatButtona.getParent() == null) { //102
//            layoutParams.x = location[0];
//            layoutParams.y = location[1] - 101 / 2 - 22;
            relativeLayoutnew.leftMargin = location[0];
            relativeLayoutnew.topMargin = location[1] - 101 / 2 - 22;
            floatButtona.setLayoutParams(relativeLayoutnew);
            relativeLayoutMain.addView(floatButtona, relativeLayoutnew);
            listFa.add(floatButtona);
            v.setVisibility(View.INVISIBLE);
        }
        floatButtona.setOnTouchListener(this);
//        floatButton = new FrameLayout(this);
//        floatButton.setBackgroundDrawable(resource);
//        listF.add(floatButton);
        // floatButtona.setOnTouchListener(this);
        return floatButton;
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public boolean onLongClick(View v) {
        switch (v.getId()) {
            case R.id.button_changgu_lb:
                v.setTag("KEY_LB");
                addFloatLayout(v, R.drawable.lb);
                break;
            case R.id.button_changgu_lt:
                v.setTag("KEY_LT");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgu_ls:
                v.setTag("KEY_LS");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgu_rb:
                v.setTag("KEY_RB");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgu_rt:
                v.setTag("KEY_RT");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgu_rs:
                v.setTag("KEY_RS");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_xiangzuo:
                v.setTag("KEY_LEFT");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_xiangyou:
                v.setTag("KEY_RIGHT");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_xiangshang:
                v.setTag("KEY_TOP");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_xiangxia:
                v.setTag("KEY_DOWN");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_back:
                v.setTag("KEY_BACK");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_m1:
                v.setTag("KEY_M1");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_m2:
                v.setTag("KEY_M2");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_m3:
                v.setTag("KEY_M3");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_m4:
                v.setTag("KEY_M4");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_a:
                v.setTag("KEY_A");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_b:
                v.setTag("KEY_B");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_x:
                v.setTag("KEY_X");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_y:
                v.setTag("KEY_Y");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_l:
                v.setTag("KEY_L");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_changgui_r:
                v.setTag("KEY_R");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            //zuhe
            case R.id.button_zuhe_lb_a:
                v.setTag("KEY_LB_A");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_lb_b:
                v.setTag("KEY_LB_B");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_lt_a:
                v.setTag("KEY_LT_A");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_lt_b:
                v.setTag("KEY_LT_B");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_rb_a:
                v.setTag("KEY_RB_A");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_rb_b:
                v.setTag("KEY_RB_B");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_lb_x:
                v.setTag("KEY_LB_X");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_lb_y:
                v.setTag("KEY_LB_Y");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_lt_x:
                v.setTag("KEY_LT_X");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_lt_y:
                v.setTag("KEY_LT_Y");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_rb_x:
                v.setTag("KEY_RB_X");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_rb_y:
                v.setTag("KEY_RB_Y");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            //..3
            case R.id.button_zuhe_m1_a:
                v.setTag("KEY_M1_A");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m1_b:
                v.setTag("KEY_M1_B");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m2_a:
                v.setTag("KEY_M2_A");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m2_b:
                v.setTag("KEY_M2_B");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_rt_a:
                v.setTag("KEY_RT_A");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_rt_b:
                v.setTag("KEY_RT_B");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            //..4
            case R.id.button_zuhe_m1_x:
                v.setTag("KEY_M1_X");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m1_y:
                v.setTag("KEY_M1_Y");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m2_x:
                v.setTag("KEY_M2_X");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m2_y:
                v.setTag("KEY_M2_Y");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_rt_x:
                v.setTag("KEY_RT_X");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_rt_y:
                v.setTag("KEY_RT_Y");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            //..5
            case R.id.button_zuhe_m3_a:
                v.setTag("KEY_M3_A");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m3_b:
                v.setTag("KEY_M3_B");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m4_a:
                v.setTag("KEY_M4_A");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m4_b:
                v.setTag("KEY_M4_B");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            //..6
            case R.id.button_zuhe_m3_x:
                v.setTag("KEY_M3_X");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m3_y:
                v.setTag("KEY_M3_Y");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m4_x:
                v.setTag("KEY_M4_X");
                addFloatLayout(v, R.drawable.xf_lt);
                break;
            case R.id.button_zuhe_m4_y:
                v.setTag("KEY_M4_Y");
                addFloatLayout(v, R.drawable.xf_lt);
                break;

        }

        return true;
    }

    private void addFloatLayout(View v, int resouce) {
        scrollEnable = true;
        isUp = true;
//      scrollViewChangGui.scrollTo(0, 0);
        final FrameLayout floatButton = initFloatButton(v.getBackground(), v);
    }

    @SuppressLint("WrongConstant")
    private void init() {

        deviceName = (TextView) findViewById(R.id.device_name);
        textView1 = (TextView) findViewById(R.id.recieve_text);

        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();


        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }


        relativeLayoutMain = findViewById(R.id.main);

        listF = new ArrayList<FrameLayout>();
        listFa = new ArrayList<Button>();
        buttonChangGuiLB = findViewById(R.id.button_changgu_lb);
        buttonChangGuiLB.setOnClickListener(this);
        buttonChangGuiLB.setOnLongClickListener(this);
        buttonChangGuiLT = findViewById(R.id.button_changgu_lt);
        buttonChangGuiLT.setOnClickListener(this);
        buttonChangGuiLT.setOnLongClickListener(this);
        buttonChangGuiLS = findViewById(R.id.button_changgu_ls);
        buttonChangGuiLS.setOnClickListener(this);
        buttonChangGuiLS.setOnLongClickListener(this);
        buttonChangGuiRB = findViewById(R.id.button_changgu_rb);
        buttonChangGuiRB.setOnClickListener(this);
        buttonChangGuiRB.setOnLongClickListener(this);
        buttonChangGuiRT = findViewById(R.id.button_changgu_rt);
        buttonChangGuiRT.setOnClickListener(this);
        buttonChangGuiRT.setOnLongClickListener(this);
        buttonChangGuiRS = findViewById(R.id.button_changgu_rs);
        buttonChangGuiRS.setOnClickListener(this);
        buttonChangGuiRS.setOnLongClickListener(this);
        //------------------2
        buttonChangGuiZUO = findViewById(R.id.button_changgui_xiangzuo);
        buttonChangGuiZUO.setOnClickListener(this);
        buttonChangGuiZUO.setOnLongClickListener(this);
        buttonChangGuiYOU = findViewById(R.id.button_changgui_xiangyou);
        buttonChangGuiYOU.setOnClickListener(this);
        buttonChangGuiYOU.setOnLongClickListener(this);
        buttonChangGuiSHANG = findViewById(R.id.button_changgui_xiangshang);
        buttonChangGuiSHANG.setOnClickListener(this);
        buttonChangGuiSHANG.setOnLongClickListener(this);
        buttonChangGuiXIA = findViewById(R.id.button_changgui_xiangxia);
        buttonChangGuiXIA.setOnClickListener(this);
        buttonChangGuiXIA.setOnLongClickListener(this);
        buttonChangGuiBK = findViewById(R.id.button_changgui_back);
        buttonChangGuiBK.setOnClickListener(this);
        buttonChangGuiBK.setOnLongClickListener(this);
        //------------------3
        buttonChangGuiM1 = findViewById(R.id.button_changgui_m1);
        buttonChangGuiM1.setOnClickListener(this);
        buttonChangGuiM1.setOnLongClickListener(this);
        buttonChangGuiM2 = findViewById(R.id.button_changgui_m2);
        buttonChangGuiM2.setOnClickListener(this);
        buttonChangGuiM2.setOnLongClickListener(this);
        buttonChangGuiM3 = findViewById(R.id.button_changgui_m3);
        buttonChangGuiM3.setOnClickListener(this);
        buttonChangGuiM3.setOnLongClickListener(this);
        buttonChangGuiM4 = findViewById(R.id.button_changgui_m4);
        buttonChangGuiM4.setOnClickListener(this);
        buttonChangGuiM4.setOnLongClickListener(this);
        //------------------4
        buttonChangGuiA = findViewById(R.id.button_changgui_a);
        buttonChangGuiA.setOnClickListener(this);
        buttonChangGuiA.setOnLongClickListener(this);
        buttonChangGuiB = findViewById(R.id.button_changgui_b);
        buttonChangGuiB.setOnClickListener(this);
        buttonChangGuiB.setOnLongClickListener(this);
        buttonChangGuiX = findViewById(R.id.button_changgui_x);
        buttonChangGuiX.setOnClickListener(this);
        buttonChangGuiX.setOnLongClickListener(this);
        buttonChangGuiY = findViewById(R.id.button_changgui_y);
        buttonChangGuiY.setOnClickListener(this);
        buttonChangGuiY.setOnLongClickListener(this);
        buttonChangGuiL = findViewById(R.id.button_changgui_l);
        buttonChangGuiL.setOnClickListener(this);
        buttonChangGuiL.setOnLongClickListener(this);
        buttonChangGuiR = findViewById(R.id.button_changgui_r);
        buttonChangGuiR.setOnClickListener(this);
        buttonChangGuiR.setOnLongClickListener(this);

        /*zuhe*/
        //------------------1
        buttonZuHeLB_A = findViewById(R.id.button_zuhe_lb_a);
        buttonZuHeLB_A.setOnClickListener(this);
        buttonZuHeLB_A.setOnLongClickListener(this);
        buttonZuHeLB_B = findViewById(R.id.button_zuhe_lb_b);
        buttonZuHeLB_B.setOnClickListener(this);
        buttonZuHeLB_B.setOnLongClickListener(this);
        buttonZuHeLT_A = findViewById(R.id.button_zuhe_lt_a);
        buttonZuHeLT_A.setOnClickListener(this);
        buttonZuHeLT_A.setOnLongClickListener(this);
        buttonZuHeLT_B = findViewById(R.id.button_zuhe_rb_b);
        buttonZuHeLT_B.setOnClickListener(this);
        buttonZuHeLT_B.setOnLongClickListener(this);
        buttonZuHeRB_A = findViewById(R.id.button_zuhe_rb_a);
        buttonZuHeRB_A.setOnClickListener(this);
        buttonZuHeRB_A.setOnLongClickListener(this);
        buttonZuHeRB_B = findViewById(R.id.button_changgu_rb);
        buttonZuHeRB_B.setOnClickListener(this);
        buttonZuHeRB_B.setOnLongClickListener(this);
        //------------------2
        buttonZuHeLB_X = findViewById(R.id.button_zuhe_lb_x);
        buttonZuHeLB_X.setOnClickListener(this);
        buttonZuHeLB_X.setOnLongClickListener(this);
        buttonZuHeLB_Y = findViewById(R.id.button_zuhe_lb_y);
        buttonZuHeLB_Y.setOnClickListener(this);
        buttonZuHeLB_Y.setOnLongClickListener(this);
        buttonZuHeLT_X = findViewById(R.id.button_zuhe_lt_x);
        buttonZuHeLT_X.setOnClickListener(this);
        buttonZuHeLT_X.setOnLongClickListener(this);
        buttonZuHeLT_Y = findViewById(R.id.button_zuhe_lt_y);
        buttonZuHeLT_Y.setOnClickListener(this);
        buttonZuHeLT_Y.setOnLongClickListener(this);
        buttonZuHeRB_X = findViewById(R.id.button_zuhe_rb_x);
        buttonZuHeRB_X.setOnClickListener(this);
        buttonZuHeRB_X.setOnLongClickListener(this);
        buttonZuHeRB_Y = findViewById(R.id.button_zuhe_rb_y);
        buttonZuHeRB_Y.setOnClickListener(this);
        buttonZuHeRB_Y.setOnLongClickListener(this);
        //------------------3
        buttonZuHeM1_A = findViewById(R.id.button_zuhe_m1_a);
        buttonZuHeM1_A.setOnClickListener(this);
        buttonZuHeM1_A.setOnLongClickListener(this);
        buttonZuHeM1_B = findViewById(R.id.button_zuhe_m1_b);
        buttonZuHeM1_B.setOnClickListener(this);
        buttonZuHeM1_B.setOnLongClickListener(this);
        buttonZuHeM2_A = findViewById(R.id.button_zuhe_m2_a);
        buttonZuHeM2_A.setOnClickListener(this);
        buttonZuHeM2_A.setOnLongClickListener(this);
        buttonZuHeM2_B = findViewById(R.id.button_zuhe_m2_b);
        buttonZuHeM2_B.setOnClickListener(this);
        buttonZuHeM2_B.setOnLongClickListener(this);
        buttonZuHeRT_A = findViewById(R.id.button_zuhe_rt_a);
        buttonZuHeRT_A.setOnClickListener(this);
        buttonZuHeRT_A.setOnLongClickListener(this);
        buttonZuHeRT_B = findViewById(R.id.button_zuhe_rt_b);
        buttonZuHeRT_B.setOnClickListener(this);
        buttonZuHeRT_B.setOnLongClickListener(this);
        //------------------4
        buttonZuHeM1_X = findViewById(R.id.button_zuhe_m1_x);
        buttonZuHeM1_X.setOnClickListener(this);
        buttonZuHeM1_X.setOnLongClickListener(this);
        buttonZuHeM1_Y = findViewById(R.id.button_zuhe_m1_y);
        buttonZuHeM1_Y.setOnClickListener(this);
        buttonZuHeM1_Y.setOnLongClickListener(this);
        buttonZuHeM2_X = findViewById(R.id.button_zuhe_m2_x);
        buttonZuHeM2_X.setOnClickListener(this);
        buttonZuHeM2_X.setOnLongClickListener(this);
        buttonZuHeM2_Y = findViewById(R.id.button_zuhe_m2_y);
        buttonZuHeM2_Y.setOnClickListener(this);
        buttonZuHeM2_Y.setOnLongClickListener(this);
        buttonZuHeRT_X = findViewById(R.id.button_zuhe_rt_x);
        buttonZuHeRT_X.setOnClickListener(this);
        buttonZuHeRT_X.setOnLongClickListener(this);
        buttonZuHeRT_Y = findViewById(R.id.button_zuhe_rt_y);
        buttonZuHeRT_Y.setOnClickListener(this);
        buttonZuHeRT_Y.setOnLongClickListener(this);
        //------------------5
        buttonZuHeM3_A = findViewById(R.id.button_zuhe_m3_a);
        buttonZuHeM3_A.setOnClickListener(this);
        buttonZuHeM3_A.setOnLongClickListener(this);
        buttonZuHeM3_B = findViewById(R.id.button_zuhe_m3_b);
        buttonZuHeM3_B.setOnClickListener(this);
        buttonZuHeM3_B.setOnLongClickListener(this);
        buttonZuHeM4_A = findViewById(R.id.button_zuhe_m4_a);
        buttonZuHeM3_A.setOnClickListener(this);
        buttonZuHeM3_A.setOnLongClickListener(this);
        buttonZuHeM4_B = findViewById(R.id.button_zuhe_m4_b);
        buttonZuHeM3_B.setOnClickListener(this);
        buttonZuHeM3_B.setOnLongClickListener(this);
        //------------------6
        buttonZuHeM3_X = findViewById(R.id.button_zuhe_m3_x);
        buttonZuHeM3_X.setOnClickListener(this);
        buttonZuHeM3_X.setOnLongClickListener(this);
        buttonZuHeM3_Y = findViewById(R.id.button_zuhe_m3_y);
        buttonZuHeM3_Y.setOnClickListener(this);
        buttonZuHeM3_Y.setOnLongClickListener(this);
        buttonZuHeM4_X = findViewById(R.id.button_zuhe_m4_x);
        buttonZuHeM4_X.setOnClickListener(this);
        buttonZuHeM3_Y.setOnLongClickListener(this);
        buttonZuHeM4_Y = findViewById(R.id.button_zuhe_m4_y);
        buttonZuHeM4_Y.setOnClickListener(this);
        buttonZuHeM4_Y.setOnLongClickListener(this);
//        view = LayoutInflater.from(this).inflate(R.layout.activity_float, null);
//        Button button = view.findViewById(R.id.f_button);
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "ttttttttt", Toast.LENGTH_LONG).show();
//            }
//        });
    }


    public void onClickChangGui(View view) {
        mapPresent.showChangGui();
    }

    public void onClickZuHe(View view) {
        mapPresent.showZuHe();
    }

    public static List<KeyValue> removeDuplicate(List<KeyValue> list) {
        for (int i = 0; i < list.size() - 1; i++) {
            for (int j = list.size() - 1; j > i; j--) {
                if (list.get(j).getKeyName().equals(list.get(i).getKeyName())) {
                    list.remove(j);
                }
            }
        }
        return list;
    }

    public void onClickQueDing(View view) {
        String s = Environment.getExternalStorageDirectory().toString() + "/json.xml";
        listKeyValue = removeDuplicate(listKeyValue);
        Gson gson = new Gson();
        System.out.println("------------:" + gson.toJson(listKeyValue));
        //saveData(s, mapJianWei);
        sendDateBluetooth(mapJianWei);
        mapJianWei.getKeyTemplate().getList().clear();
    }

    public int StringCount(String str) {
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            String s = String.valueOf(str.charAt(i));
            if (s.equals("_")) {
                count++;
            }
        }
        return count;
    }

    private void sendDateBluetooth(MapJianWei mapJianWei) {
        if (mBluetoothGatt != null && isServiceConnected) {
            BluetoothGattService gattService = mBluetoothGatt.getService(UUID_SERVICE);
            BluetoothGattCharacteristic characteristic = gattService.getCharacteristic(UUID_WRITE);
            if (mapJianWei != null) {
                List<KeyValue> listValues = mapJianWei.getKeyTemplate().getList();
                for (int i = 0; i < listValues.size(); i++) {
                    KeyValue keyValue = listValues.get(i);
                    if (keyValue != null) {
                        if (StringCount(keyValue.getKeyName()) >= 2) { //zuhe
                            byte[] keyMap = new byte[19];
                            keyMap[0] = 0x13;
                            //按键值
                            byte x = getKey(keyValue.getKeyName());
                            keyMap[1] = x;
                            //按键坐标x
                            int px = keyValue.getPostion().getX();
                            int py = keyValue.getPostion().getY();
                            keyMap[2] = intToByte4(px)[0];
                            keyMap[3] = intToByte4(px)[1];
                            //按键坐标y
                            keyMap[4] = intToByte4(py)[0];
                            keyMap[5] = intToByte4(py)[1];
                            //属性值：  1：点击
                            keyMap[6] = 1;
                            characteristic.setValue(keyMap);
                            characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                            mBluetoothGatt.writeCharacteristic(characteristic);
                        } else {
                            byte[] keyMap = new byte[19];
                            keyMap[0] = 0x11;
                            //按键值
                            byte x = getKey(keyValue.getKeyName());
                            keyMap[1] = x;
                            //按键坐标x
                            int px = keyValue.getPostion().getX();
                            int py = keyValue.getPostion().getY();
                            keyMap[2] = intToByte4(px)[0];
                            keyMap[3] = intToByte4(px)[1];
                            //按键坐标y
                            keyMap[4] = intToByte4(py)[0];
                            keyMap[5] = intToByte4(py)[1];
                            //属性值：  1：点击
                            keyMap[6] = 1;
                            characteristic.setValue(keyMap);
                            characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                            mBluetoothGatt.writeCharacteristic(characteristic);
                        }
                    }
                }
            } else return;

            /*
             * 3) 摇杆映射数据(UUID :0x7F12)
             */


            /*
             *4) 组合按键映射(UUID :0x7F12)
                 *            组合按键值：
                            按键                             值
                            L1+A                             1
                            L1+B                             2
                            L1+X                             3
                            L1+Y                             4

             */
            byte[] zuHeMap = new byte[19];
            zuHeMap[0] = 0x13;
            zuHeMap[1] = 0x13;  //按键值
            zuHeMap[2] = intToByte4(100)[0];//按键坐标 X
            zuHeMap[3] = intToByte4(100)[1];//按键坐标 x
            zuHeMap[4] = intToByte4(100)[0];//按键坐标 y
            zuHeMap[5] = intToByte4(100)[1];//按键坐标 y
          /*  属性值：
            1：点击
            2：关联摇杆
            3：关联划屏*/
            zuHeMap[6] = 1;
            zuHeMap[7] = 0;//0表示单次点击;
            zuHeMap[8] = 0;  //为0时表示关联右摇杆，为1时表示左摇杆
            zuHeMap[9] = 0x13;
            zuHeMap[10] = 0x13;

            byte[] rAndO = new byte[20];
            rAndO[0] = 0x10;
            //分辨率，⻓长度的数据
            rAndO[1] = intToByte4(2960)[0];
            rAndO[2] = intToByte4(2960)[1];
//            分辨率，宽度的数据 (2 Bytes
            rAndO[3] = intToByte4(1440)[0];
            rAndO[4] = intToByte4(1440)[1];
//            0： 表示屏幕没有旋转
//            1： 表示屏幕有旋转
            rAndO[5] = 0;
            rAndO[7] = 0x10;
            rAndO[8] = 0x10;
            rAndO[9] = 0x10;
            rAndO[10] = 0x10;
            rAndO[11] = 0x10;

            byte[] rAnd111 = new byte[20];
            rAndO[0] = 0x11;
            //分辨率，⻓长度的数据
            rAndO[1] = 1;
            rAndO[2] = intToByte4(900)[0];
            rAndO[3] = intToByte4(900)[1];
//            分辨率，宽度的数据 (2 Bytes
            rAndO[4] = intToByte4(600)[0];
            rAndO[5] = intToByte4(600)[1];
//            0： 表示屏幕没有旋转
//            1： 表示屏幕有旋转
            rAndO[6] = 1;
            rAndO[7] = 0;
            rAndO[8] = 0;
            rAndO[9] = 0;
            rAndO[10] = 0;
            rAndO[11] = 0;

            characteristic.setValue(rAnd111);
            characteristic.setValue(rAndO);
            characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            mBluetoothGatt.writeCharacteristic(characteristic);


            /**
             *  1)  发送屏幕分辨率和转向
             */
            byte[] rAndO0 = new byte[19];
            rAndO[0] = 0x10;
            //分辨率，⻓长度的数据
            rAndO[1] = intToByte4(1080)[0];
            rAndO[2] = intToByte4(1080)[1];
//            分辨率，宽度的数据 (2 Bytes
            rAndO[3] = intToByte4(1920)[0];
            rAndO[4] = intToByte4(1920)[1];
//            0： 表示屏幕没有旋转
//            1： 表示屏幕有旋转
            rAndO[5] = 01;
            rAndO[7] = 0x10;
            rAndO[8] = 0x10;
            rAndO[9] = 0x10;
            rAndO[10] = 0x10;
            rAndO[11] = 0x10;

            /**
             * 2) 　按键映射数据(UUID :0x7F12)
             */
            byte[] keyMap = new byte[19];
            keyMap[0] = 0x11;
            //按键值
            keyMap[1] = 1;
            //按键坐标x
            keyMap[2] = intToByte4(50)[0];
            keyMap[3] = intToByte4(50)[1];
            //按键坐标y
            keyMap[4] = intToByte4(50)[0];
            keyMap[5] = intToByte4(50)[0];
            //属性值：  1：点击
            keyMap[6] = 0;

            /*
             * 3) 摇杆映射数据(UUID :0x7F12)
             */


            /*
             *4) 组合按键映射(UUID :0x7F12)
                 *            组合按键值：
                            按键                             值
                            L1+A                             1
                            L1+B                             2
                            L1+X                             3
                            L1+Y                             4

             */
            byte[] zuHeMapd = new byte[19];
            zuHeMap[0] = 0x13;
            zuHeMap[1] = 0x13;  //按键值
            zuHeMap[2] = intToByte4(100)[0];//按键坐标 X
            zuHeMap[3] = intToByte4(100)[1];//按键坐标 x
            zuHeMap[4] = intToByte4(100)[0];//按键坐标 y
            zuHeMap[5] = intToByte4(100)[1];//按键坐标 y
          /*  属性值：
            1：点击
            2：关联摇杆
            3：关联划屏*/
            zuHeMap[6] = 1;
            zuHeMap[7] = 0;//0表示单次点击;
            zuHeMap[8] = 0;  //为0时表示关联右摇杆，为1时表示左摇杆
            zuHeMap[9] = 0x13;
            zuHeMap[10] = 0x13;
        }
    }

    private byte getKey(String keyName) {
        byte a = 0;
        if (keyName.equals("KEY_A")) {
            a = 1;
        }
        if (keyName.equals("KEY_B")) {
            a = 2;
        }
        if (keyName.equals("KEY_X")) {
            a = 3;
        }
        if (keyName.equals("KEY_Y")) {
            a = 4;
        }
        if (keyName.equals("KEY_UP")) {
            a = 5;
        }
        if (keyName.equals("KEY_DOWN")) {
            a = 6;
        }
        if (keyName.equals("KEY_LEFT")) {
            a = 7;
        }
        if (keyName.equals("KEY_RIGHT")) {
            a = 8;
        }
        if (keyName.equals("KEY_L1")) {
            a = 9;
        }
        if (keyName.equals("KEY_R1")) {
            a = 0x0A;
        }
        if (keyName.equals("KEY_LT")) {
            a = 0x0B;
        }
        if (keyName.equals("KEY_RT")) {
            a = 0x0C;
        }
        if (keyName.equals("KEY_M1")) {
            a = 0x0D;
        }
        if (keyName.equals("KEY_M2")) {
            a = 0x0E;
        }
        if (keyName.equals("KEY_M3")) {
            a = 0x0F;
        }
        if (keyName.equals("KEY_M4")) {
            a = 0x10;
        }
        if (keyName.equals("KEY_C1")) {
            a = 0x11;
        }
        if (keyName.equals("KEY_C2")) {
            a = 0x12;
        }
        if (keyName.equals("KEY_MOHE")) {
            a = 0x13;
        }
        //组合
        if (keyName.equals("KEY_L1_A")) {
            a = 1;
        }
        if (keyName.equals("KEY_L1_B")) {
            a = 2;
        }
        if (keyName.equals("KEY_L1_X")) {
            a = 3;
        }
        if (keyName.equals("KEY_L1_Y")) {
            a = 4;
        }
        if (keyName.equals("KEY_L2_A")) {
            a = 5;
        }
        if (keyName.equals("KEY_L2_B")) {
            a = 6;
        }
        if (keyName.equals("KEY_L2_X")) {
            a = 7;
        }
        if (keyName.equals("KEY_L2_Y")) {
            a = 8;
        }
        if (keyName.equals("KEY_R1_A")) {
            a = 9;
        }
        if (keyName.equals("KEY_R1_B")) {
            a = 0x0A;
        }
        if (keyName.equals("KEY_R1_X")) {
            a = 0x0B;
        }
        if (keyName.equals("KEY_R1_Y")) {
            a = 0x0C;
        }
        if (keyName.equals("KEY_R2_A")) {
            a = 0x0D;
        }
        if (keyName.equals("KEY_R2_B")) {
            a = 0x0E;
        }
        if (keyName.equals("KEY_R2_X")) {
            a = 0x0F;
        }
        if (keyName.equals("KEY_R2_Y")) {
            a = 0x10;
        }
        if (keyName.equals("KEY_M1_A")) {
            a = 0x11;
        }
        if (keyName.equals("KEY_M1_B")) {
            a = 0x12;
        }
        if (keyName.equals("KEY_M1_X")) {
            a = 0x13;
        }
        if (keyName.equals("KEY_M1_Y")) {
            a = 0x14;
        }
        if (keyName.equals("KEY_M2_A")) {
            a = 0x15;
        }
        if (keyName.equals("KEY_M2_B")) {
            a = 0x16;
        }
        if (keyName.equals("KEY_M2_X")) {
            a = 0x17;
        }
        if (keyName.equals("KEY_M2_Y")) {
            a = 0x18;
        }
        if (keyName.equals("KEY_M3_A")) {
            a = 0x19;
        }
        if (keyName.equals("KEY_M3_B")) {
            a = 0x1A;
        }
        if (keyName.equals("KEY_M3_X")) {
            a = 0x1B;
        }
        if (keyName.equals("KEY_M3_Y")) {
            a = 0x1C;
        }
        if (keyName.equals("KEY_M4_A")) {
            a = 0x1D;
        }
        if (keyName.equals("KEY_M4_B")) {
            a = 0x1F;
        }
        if (keyName.equals("KEY_M4_X")) {
            a = 0x20;
        }
        if (keyName.equals("KEY_M4_Y")) {
            a = 0x21;
        }
        return a;
    }

    @Override
    public void setTurnScreenOn(boolean turnScreenOn) {
        super.setTurnScreenOn(turnScreenOn);
    }

    public void onClickClean(View view) {
        for (int i = 0; i < buttons.size(); i++) {
            Button frameLayout = buttons.get(i);
            if (relativeLayoutMain != null && frameLayout.getParent() != null) {
                relativeLayoutMain.removeView(frameLayout);
            }
        }
        for (int x = 0; x < listFa.size(); x++) {
            Button frameLayout = listFa.get(x);
            if (relativeLayoutMain != null && frameLayout.getParent() != null) {
                relativeLayoutMain.removeView(frameLayout);
            }
        }
        listFa.clear();
        buttonChangGuiLB.setVisibility(View.VISIBLE);
        buttonChangGuiLT.setVisibility(View.VISIBLE);
        buttonChangGuiLS.setVisibility(View.VISIBLE);
        buttonChangGuiRT.setVisibility(View.VISIBLE);
        buttonChangGuiRB.setVisibility(View.VISIBLE);
        buttonChangGuiRS.setVisibility(View.VISIBLE);

        buttonChangGuiZUO.setVisibility(View.VISIBLE);
        buttonChangGuiYOU.setVisibility(View.VISIBLE);
        buttonChangGuiSHANG.setVisibility(View.VISIBLE);
        buttonChangGuiXIA.setVisibility(View.VISIBLE);
        buttonChangGuiBK.setVisibility(View.VISIBLE);

        buttonChangGuiM1.setVisibility(View.VISIBLE);
        buttonChangGuiM2.setVisibility(View.VISIBLE);
        buttonChangGuiM3.setVisibility(View.VISIBLE);
        buttonChangGuiM4.setVisibility(View.VISIBLE);

        buttonChangGuiA.setVisibility(View.VISIBLE);
        buttonChangGuiB.setVisibility(View.VISIBLE);
        buttonChangGuiX.setVisibility(View.VISIBLE);
        buttonChangGuiY.setVisibility(View.VISIBLE);
        buttonChangGuiL.setVisibility(View.VISIBLE);
        buttonChangGuiR.setVisibility(View.VISIBLE);
        buttonZuHeLB_A.setVisibility(View.VISIBLE);
        buttonZuHeLB_B.setVisibility(View.VISIBLE);
        buttonZuHeLT_A.setVisibility(View.VISIBLE);
        buttonZuHeLT_B.setVisibility(View.VISIBLE);
        buttonZuHeRB_A.setVisibility(View.VISIBLE);
        buttonZuHeRB_B.setVisibility(View.VISIBLE);
        //....2
        buttonZuHeLB_X.setVisibility(View.VISIBLE);
        buttonZuHeLB_Y.setVisibility(View.VISIBLE);
        buttonZuHeLT_X.setVisibility(View.VISIBLE);
        buttonZuHeLT_Y.setVisibility(View.VISIBLE);
        buttonZuHeRB_X.setVisibility(View.VISIBLE);
        buttonZuHeRB_Y.setVisibility(View.VISIBLE);
        //....3
        buttonZuHeM1_A.setVisibility(View.VISIBLE);
        buttonZuHeM1_B.setVisibility(View.VISIBLE);
        buttonZuHeM2_A.setVisibility(View.VISIBLE);
        buttonZuHeM2_B.setVisibility(View.VISIBLE);
        buttonZuHeRT_A.setVisibility(View.VISIBLE);
        buttonZuHeRT_B.setVisibility(View.VISIBLE);
        //...4
        buttonZuHeM1_X.setVisibility(View.VISIBLE);
        buttonZuHeM1_Y.setVisibility(View.VISIBLE);
        buttonZuHeM2_X.setVisibility(View.VISIBLE);
        buttonZuHeM2_Y.setVisibility(View.VISIBLE);
        buttonZuHeRT_X.setVisibility(View.VISIBLE);
        buttonZuHeRT_Y.setVisibility(View.VISIBLE);

        //...5
        buttonZuHeM3_A.setVisibility(View.VISIBLE);
        buttonZuHeM3_B.setVisibility(View.VISIBLE);
        buttonZuHeM4_A.setVisibility(View.VISIBLE);
        buttonZuHeM4_B.setVisibility(View.VISIBLE);
        //...6
        buttonZuHeM3_X.setVisibility(View.VISIBLE);
        buttonZuHeM3_Y.setVisibility(View.VISIBLE);
        buttonZuHeM4_X.setVisibility(View.VISIBLE);
        buttonZuHeM4_Y.setVisibility(View.VISIBLE);

    }

    @Override
    public void showChangGunPanel(View view) {
        view.setVisibility(View.VISIBLE);
    }

    @Override
    public void showZuHePanel(View view) {
        view.setVisibility(View.VISIBLE);
    }

    /**
     * 用于获取状态栏的高度。
     *
     * @return 返回状态栏高度的像素值。
     */
    private int getStatusBarHeight() {
        if (statusBarHeight == 0) {
            try {
                Class<?> c = Class.forName("com.android.internal.R$dimen");
                Object o = c.newInstance();
                Field field = c.getField("status_bar_height");
                int x = (Integer) field.get(o);
                statusBarHeight = getResources().getDimensionPixelSize(x);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return statusBarHeight;
    }

    @Override
    protected void onDestroy() {
        if (mBluetoothGatt != null) {
            mBluetoothGatt.close();
        }
        super.onDestroy();
    }

    /**
     * 判断当前界面是否是桌面
     */
    private boolean isHome() {
        ActivityManager mActivityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> rti = mActivityManager.getRunningTasks(1);
        return getHomes().contains(rti.get(0).topActivity.getPackageName());
    }

    /**
     * 获得属于桌面的应用的应用包名称
     *
     * @return 返回包含所有包名的字符串列表
     */
    private List<String> getHomes() {
        List<String> names = new ArrayList<String>();
        PackageManager packageManager = this.getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        List<ResolveInfo> resolveInfo = packageManager.queryIntentActivities(intent,
                PackageManager.MATCH_DEFAULT_ONLY);
        for (ResolveInfo ri : resolveInfo) {
            names.add(ri.activityInfo.packageName);
        }
        return names;
    }


    public void onClickGuanBi(View view) {
        view.setBackgroundResource(R.drawable.img_button_blue);
        findViewById(R.id.queding).setBackgroundResource(R.drawable.img_button_grade);
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
        float px = 0;
        float py = 0;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                px = event.getRawX();
                py = event.getRawY();
                downX = event.getX();
                downY = event.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                float x = event.getRawX();
                float y = event.getRawY();
                final float xDistance = event.getX() - downX;
                final float yDistance = event.getY() - downY;
                if (xDistance != 0 && yDistance != 0) {
                    int l = (int) (v.getLeft() + xDistance);
                    int r = (int) (v.getRight() + xDistance);
                    int t = (int) (v.getTop() + yDistance);
                    int b = (int) (v.getBottom() + yDistance);
                    //v.layout(l, t, r, b);
                    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(102, 102);
                    layoutParams.leftMargin = l;
                    layoutParams.topMargin = t;
                    v.setLayoutParams(layoutParams);
                    break;
                }
                //setMove((int) (x - 50 / 2), (int) (y - 50*2));
            case MotionEvent.ACTION_UP:
                addKeyToMap(v, (int) event.getRawY(), (int) event.getRawY());
                Toast.makeText(MainActivity.this, "x值:" + event.getX() + "  y值:" + event.getY(), Toast.LENGTH_SHORT).show();
                break;
        }
        return false;
    }

    private void addKeyToMap(View v, int x, int y) {
        KeyValue keyValue = new KeyValue();
        keyValue.setKeyName(v.getTag().toString());
        keyValue.setMode("0");
        Postion postion = new Postion();
        postion.setX(x);
        postion.setY(y);
        keyValue.setPostion(postion);
        RelateProp relateProp = new RelateProp();
        relateProp.setKeyName(v.getTag().toString());
        relateProp.setSeriesClickTimes("seriesClickTimes");
        relateProp.setValue("0");
        keyValue.setRelateProp(relateProp);
        if (keyValue != null) {
            listKeyValue.add(keyValue);
            keyTemplate.setList(listKeyValue);
            mapJianWei.setKeyTemplate(keyTemplate);
        }

    }

    AKeyTemplate keyTemplate2 = new AKeyTemplate();


    private BluetoothAdapter mBluetoothAdapter;
    private Handler mHandler = new Handler();
    private boolean mScanning;

    final UUID UUID_SERVICE = UUID.fromString("00007F10-0000-1000-8000-00805F9B34FB");
    //  设备特征值UUID, 需固件配合同时修改
    final UUID UUID_WRITE = UUID.fromString("00007F12-0000-1000-8000-00805F9B34FB");  // 用于发送数据到设备
    final UUID UUID_NOTIFICATION = UUID.fromString("00007F13-0000-1000-8000-00805F9B34FB"); // 用于接收设备推送的数据
    final UUID UUID_NOTIFICATION_START = UUID.fromString("00007F11-0000-1000-8000-00805F9B34FB"); // 用于接收设备推送的数据

    private BluetoothGatt mBluetoothGatt;
    private TextView deviceName;
    private TextView textView1;
    private BluetoothDevice mDevice;

    public void connectlanya(View view) {
        if (findViewById(R.id.lanyaPanle).getVisibility() == View.VISIBLE) {
            findViewById(R.id.lanyaPanle).setVisibility(View.INVISIBLE);
        } else {
            findViewById(R.id.lanyaPanle).setVisibility(View.VISIBLE);
        }
    }

    final BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
            Log.d("haha", "onLeScan:  " + device.getName() + " uuid:" + device.getUuids() + " : " + rssi);
            String name = device.getName();
            if (name != null) {
                deviceName.setText(name);
                if (name.contains("SMOS-P1")) {
                    mDevice = device;
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                }
            }
        }

    };

    public void startScan(View view) {
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mScanning = false;
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            }
        }, 30000);
        mScanning = true;
        // 定义一个回调接口供扫描结束处理
        mBluetoothAdapter.startLeScan(mLeScanCallback);
    }

    private String TAG = "haha";
    private boolean isServiceConnected;


    public void startConnect(View view) {
        if (mDevice != null) {
            if (mBluetoothGatt != null) {
                mBluetoothGatt.disconnect();
                mBluetoothGatt.close();
                mBluetoothGatt = null;
            }
            mBluetoothGatt = mDevice.connectGatt(MainActivity.this, false, mGattCallback);
        }
    }

    public void startSend() {
        if (mBluetoothGatt != null && isServiceConnected) {
            BluetoothGattService gattService = mBluetoothGatt.getService(UUID_SERVICE);
            BluetoothGattCharacteristic characteristic = gattService.getCharacteristic(UUID_WRITE);

//            byte[] bytes = new byte[20];
//            bytes[0] = 0x0A;
//            bytes[1] = 0x04;
//            bytes[2] = 0x00;
//            bytes[3] = 0x65;

            byte[] rAndO = new byte[20];
            rAndO[0] = 0x10;
            //分辨率，⻓长度的数据
            rAndO[1] = intToByte4(2960)[0];
            rAndO[2] = intToByte4(2960)[1];
//            分辨率，宽度的数据 (2 Bytes
            rAndO[3] = intToByte4(1440)[0];
            rAndO[4] = intToByte4(1440)[1];
//            0： 表示屏幕没有旋转
//            1： 表示屏幕有旋转
            rAndO[5] = 0;
            rAndO[7] = 0x10;
            rAndO[8] = 0x10;
            rAndO[9] = 0x10;
            rAndO[10] = 0x10;
            rAndO[11] = 0x10;

            byte[] rAnd111 = new byte[20];
            rAndO[0] = 0x11;
            //分辨率，⻓长度的数据
            rAndO[1] = 1;
            rAndO[2] = intToByte4(900)[0];
            rAndO[3] = intToByte4(900)[1];
//            分辨率，宽度的数据 (2 Bytes
            rAndO[4] = intToByte4(600)[0];
            rAndO[5] = intToByte4(600)[1];
//            0： 表示屏幕没有旋转
//            1： 表示屏幕有旋转
            rAndO[6] = 1;
            rAndO[7] = 0;
            rAndO[8] = 0;
            rAndO[9] = 0;
            rAndO[10] = 0;
            rAndO[11] = 0;

            characteristic.setValue(rAnd111);
            characteristic.setValue(rAndO);
            characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            mBluetoothGatt.writeCharacteristic(characteristic);


            /**
             *  1)  发送屏幕分辨率和转向
             */
            byte[] rAndO0 = new byte[19];
            rAndO[0] = 0x10;
            //分辨率，⻓长度的数据
            rAndO[1] = intToByte4(1080)[0];
            rAndO[2] = intToByte4(1080)[1];
//            分辨率，宽度的数据 (2 Bytes
            rAndO[3] = intToByte4(1920)[0];
            rAndO[4] = intToByte4(1920)[1];
//            0： 表示屏幕没有旋转
//            1： 表示屏幕有旋转
            rAndO[5] = 01;
            rAndO[7] = 0x10;
            rAndO[8] = 0x10;
            rAndO[9] = 0x10;
            rAndO[10] = 0x10;
            rAndO[11] = 0x10;

            /**
             * 2) 　按键映射数据(UUID :0x7F12)
             */
            byte[] keyMap = new byte[19];
            keyMap[0] = 0x11;
            //按键值
            keyMap[1] = 1;
            //按键坐标x
            keyMap[2] = intToByte4(50)[0];
            keyMap[3] = intToByte4(50)[1];
            //按键坐标y
            keyMap[4] = intToByte4(50)[0];
            keyMap[5] = intToByte4(50)[0];
            //属性值：  1：点击
            keyMap[6] = 0;

            /*
             * 3) 摇杆映射数据(UUID :0x7F12)
             */


            /*
             *4) 组合按键映射(UUID :0x7F12)
                 *            组合按键值：
                            按键                             值
                            L1+A                             1
                            L1+B                             2
                            L1+X                             3
                            L1+Y                             4

             */
            byte[] zuHeMap = new byte[19];
            zuHeMap[0] = 0x13;
            zuHeMap[1] = 0x13;  //按键值
            zuHeMap[2] = intToByte4(100)[0];//按键坐标 X
            zuHeMap[3] = intToByte4(100)[1];//按键坐标 x
            zuHeMap[4] = intToByte4(100)[0];//按键坐标 y
            zuHeMap[5] = intToByte4(100)[1];//按键坐标 y
          /*  属性值：
            1：点击
            2：关联摇杆
            3：关联划屏*/
            zuHeMap[6] = 1;
            zuHeMap[7] = 0;//0表示单次点击;
            zuHeMap[8] = 0;  //为0时表示关联右摇杆，为1时表示左摇杆
            zuHeMap[9] = 0x13;
            zuHeMap[10] = 0x13;
        }

    }

    public static byte[] intToByte4(int i) {
        byte[] targets = new byte[2];
        targets[0] = (byte) (i & 0xFF);
        targets[1] = (byte) (i >> 8 & 0xFF);
        return targets;
    }

    public void startRead(View view) {
        if (mDevice != null) {
            if (mBluetoothGatt != null) {
                mBluetoothGatt.disconnect();
                mBluetoothGatt.close();
                mBluetoothGatt = null;
            }
            mBluetoothGatt = mDevice.connectGatt(MainActivity.this, false, mGattCallback);
        }
    }


    public void stopConnect(View view) {
        if (mBluetoothGatt != null) {

            mBluetoothGatt.close();
        }
    }

    private BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            Log.d("haha", "onConnectionStateChange: " + newState);

            if (status != BluetoothGatt.GATT_SUCCESS) {
                String err = "Cannot connect device with error status: " + status;

                gatt.close();
                if (mBluetoothGatt != null) {
                    mBluetoothGatt.disconnect();
                    mBluetoothGatt.close();
                    mBluetoothGatt = null;
                }
                if (mDevice != null) {
                    mBluetoothGatt = mDevice.connectGatt(MainActivity.this, false, mGattCallback);
                }
                Log.e(TAG, err);
                return;
            }

            if (newState == BluetoothProfile.STATE_CONNECTED) {//当蓝牙设备已经连接

                //获取ble设备上面的服务
                // toast.makeText(MainActivity.this, "连接成功", Toast.LENGTH_SHORT).show();
                Log.i("haha", "Attempting to start service discovery:" + mBluetoothGatt.discoverServices());
                Log.d("haha", "onConnectionStateChange: " + "连接成功");
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {//当设备无法连接
                if (mBluetoothGatt != null) {
                    mBluetoothGatt.disconnect();
                    mBluetoothGatt.close();
                    mBluetoothGatt = null;
                }
                gatt.close();
                if (mDevice != null) {
                    mBluetoothGatt = mDevice.connectGatt(MainActivity.this, false, mGattCallback);
                }
            }


        }

        //发现服务回调。
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            Log.d("haha", "onServicesDiscovered: " + "发现服务 : " + status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                isServiceConnected = true;

                boolean serviceFound;
                Log.d("haha", "onServicesDiscovered: " + "发现服务 : " + status);
                Log.d(TAG, "onServicesDiscovered: " + "读取数据");
                BluetoothGattService gattService = gatt.getService(UUID_SERVICE);
                if (gattService != null && isServiceConnected) {
                    BluetoothGattCharacteristic characteristic = gattService.getCharacteristic(UUID_NOTIFICATION);
                    BluetoothGattCharacteristic characteristic0 = gattService.getCharacteristic(UUID_NOTIFICATION_START);
                    boolean b = gatt.setCharacteristicNotification(characteristic, true);
                    if (b) {
                        List<BluetoothGattDescriptor> descriptors = characteristic.getDescriptors();
                        List<BluetoothGattDescriptor> descriptors1 = characteristic0.getDescriptors();
                        for (BluetoothGattDescriptor descriptor : descriptors1) {
                            boolean b1 = descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            if (b1) {
                                gatt.writeDescriptor(descriptor);
                                Log.d(TAG, "startRead: " + "监听收数据");
                            }
                        }
                        for (BluetoothGattDescriptor descriptor : descriptors) {
                            boolean b1 = descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            if (b1) {
                                gatt.writeDescriptor(descriptor);
                                Log.d(TAG, "startRead: " + "监听收数据");
                            }
                        }
                    }
                }
                serviceFound = true;
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);
            Log.d(TAG, "read value: " + characteristic.getValue());
            Log.d(TAG, "callback characteristic read status " + status
                    + " in thread " + Thread.currentThread());
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG, "read value: " + characteristic.getValue());
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
            Log.d(TAG, "onDescriptorWrite: " + "设置成功");
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorRead(gatt, descriptor, status);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            Log.d(TAG, "onCharacteristicWrite: " + "发送成功");
            boolean b = mBluetoothGatt.setCharacteristicNotification(characteristic, true);
            mBluetoothGatt.readCharacteristic(characteristic);
        }

        @Override
        public final void onCharacteristicChanged(final BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic) {
            byte[] value = characteristic.getValue();
//            Log.d(TAG, "onCharacteristicChanged: " + value.length);
//            String s0 = Integer.toHexString(value[0] & 0xFF);
//            String s = Integer.toHexString(value[1] & 0xFF);
//             Log.d(TAG, "onCharacteristicChanged: " + s0 + "、" + s);
//            textView1.setText("收到: " + s0 + "、" + s);

            //接收到手柄start 启动...
            if (value[7] == 0x08) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName("coms.example.administrator.smosmap", "coms.example.administrator.smosmap.MainActivity"));
                startActivity(intent);
            }
            for (int i = 0; i < value.length; i++) {
                Log.d(TAG, "onCharacteristicChanged:--------------------------------------- ");
                Log.d(TAG, "onCharacteristicChanged: " + Integer.toHexString(value[i] & 0xFF));
            }

        }
    };

    List<Button> buttons = new ArrayList<>();

    public void jianweixianshi(View view) {
    }
}

