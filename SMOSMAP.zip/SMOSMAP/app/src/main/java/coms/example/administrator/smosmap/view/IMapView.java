package coms.example.administrator.smosmap.view;

import android.view.View;

public interface IMapView {
    void showChangGunPanel(View view);

    void showZuHePanel(View view);
}
