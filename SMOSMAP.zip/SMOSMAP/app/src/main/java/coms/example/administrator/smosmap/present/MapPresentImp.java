package coms.example.administrator.smosmap.present;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;

import coms.example.administrator.smosmap.MainActivity;
import coms.example.administrator.smosmap.R;
import coms.example.administrator.smosmap.view.IMapView;

public class MapPresentImp implements IMapPresent {
    private MapPresentImp() {
    }

    private Button button_changgui;
    private Button button_zuhe;
    private ScrollView scroll_changguicontent;
    private ScrollView scroll_zuhecontent;
    private IMapView mapView;
    Context context;
    private static MapPresentImp mapPresentImp;

    public static MapPresentImp getInstance() {
        if (mapPresentImp == null) {
            mapPresentImp = new MapPresentImp();
        }
        return mapPresentImp;
    }

    @Override
    public void bind(Context context) {
        this.context = context;
        mapView = (IMapView) context;
        button_changgui = ((MainActivity) context).findViewById(R.id.changgui);
        button_zuhe = ((MainActivity) context).findViewById(R.id.zuhe);
        scroll_changguicontent = ((MainActivity) context).findViewById(R.id.scroll_changguicontent);
        scroll_zuhecontent = ((MainActivity) context).findViewById(R.id.scroll_zuhecontent);
    }

    public void showChangGui() {
        if (scroll_changguicontent.getVisibility() == View.INVISIBLE) {
            if (mapView != null) {
                mapView.showChangGunPanel(scroll_changguicontent);
                scroll_zuhecontent.setVisibility(View.INVISIBLE);
            }
        }
    }

    public void showZuHe() {
        if (scroll_zuhecontent.getVisibility() == View.INVISIBLE) {
            if (mapView != null) {
                mapView.showChangGunPanel(scroll_zuhecontent);
                scroll_changguicontent.setVisibility(View.INVISIBLE);
            }
        }
    }

}
