package coms.example.administrator.smosmap.mode;

public class RelateProp {
    public String getKeyName() {
        return keyName;
    }

    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }

    private String keyName;
    private String seriesClickTimes;
    private String value;

    public String getSeriesClickTimes() {
        return seriesClickTimes;
    }

    public void setSeriesClickTimes(String seriesClickTimes) {
        this.seriesClickTimes = seriesClickTimes;
    }


    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


}
